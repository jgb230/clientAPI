package clientAPI;

import com.alibaba.fastjson.JSONObject;

public interface CallBack {
	public void callBack(JSONObject jsonObject);
}
